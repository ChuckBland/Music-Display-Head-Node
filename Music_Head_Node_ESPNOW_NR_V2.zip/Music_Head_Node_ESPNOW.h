//MSGEQ7
const int   MSGEQ7_0        = 0;    //  63 Hz
const int   MSGEQ7_1        = 1;    // 160 Hz
const int   MSGEQ7_2        = 2;    // 400 Hz
const int   MSGEQ7_3        = 3;    //   1 KHz
const int   MSGEQ7_4        = 4;    // 2.5 KHz
const int   MSGEQ7_5        = 5;    //6.25 KHz
const int   MSGEQ7_6        = 6;    //  16 KHz
const int   CHANNELS        = 2;
const int   LEFT_CHANNEL    = 0;
const int   RIGHT_CHANNEL   = 1;
const int   MSGEQ7_BANDS    = 7;

//this are the GPIOXX pin numbers on the ESP32
const int   LEFT_AUDIO_IN           = 34;//connector facing chip
const int   RIGHT_AUDIO_IN          = 35;
const int   STROBE_PIN              = 32;
const int   RESET_PIN               = 33;
const int   IR_RECEIVER             = 19;
const int   SENDING_DATA            =  5;

//Raw numbers
//Driven from computer speaker output
const int   MAX_RANGE_FACTOR    = 3000;
const int   MIN_RANGE_FACTOR    = -3000;
const int   MAX_LEVEL           = 4095;
const int   NOISE_FLOOR         = 250;
const int   NUM_READS           = 7;
const int   COARSE_AGC_ADJ      = 100;
const int   FINE_AGC_ADJ        = 10;
const int   COARSE_THRESHOLD    = 5;

int          AGCLevel            = 0;
int          numSamples;
int          LeftTempVals[NUM_READS];
int          RightTempVals[NUM_READS];
int          tmpVal;
unsigned int LeftTmpVal;
unsigned int RightTmpVal;
int          monoData[MSGEQ7_BANDS];
int          channelData[CHANNELS][MSGEQ7_BANDS];
int          channelValue;
int          AGCSum;
int          LeftADCReading;
int          RightADCReading;
int          compositeValue;
int          LeftSilenceCount=0;
int          RightSilenceCount=0;
bool         LeftSilenceFlag;
bool         RightSilenceFlag;
int          SilenceCounter=0;
bool         SystemSilenceFlag=false;
const int    CHANNEL_SILENCE_THRESHOLD = 4; //If number of silent ranges > CHANNEL_SILENCE_THRESHOLD
const int    SYSTEM_SILENCE_THRESHOLD = 20;
const int    MAX_ZERO_SAMPLES    = 4;
const int    SAMPLE_GOAL         = 50;
const int    UPPER_LED_RANGE     = 60;//reduce AGCLevel if the avg is above this
const int    LOWER_LED_RANGE     = 55;//increase AGCLevel if the avg is below this

//Display
LiquidCrystal_I2C lcd(0x27, 16, 2);
const int BACKLIGHT_TIMEOUT = 15;

//IR Decoder
IRsmallDecoder irDecoder(IR_RECEIVER);
irSmallD_t irData;
int currentPattern;
const int POWER     = 69; //displays on/off (pattern=0)
const int PLUS      =  9; //displays brighter
const int MINUS     = 21; //displays dimmer
const int NEXT      = 67; //pattern+ >>|
const int PREVIOUS  = 64; //pattern- |<<
const int MODE      = 70; //display backlight on
const int ZERO      = 22; //decrement softpot
const int ONE       = 12; //increment softpot

char        tempString[5];
const int   DEBUG_OFF               = 0x30; //'0'
const int   DEBUG_CHANNELDATA       = 0x31; //'1'
const int   DEBUG_REMOTEKEYS        = 0x32; //'2'
int         debugMode               = DEBUG_OFF; //0 - no debug output

const int   DEFAULT_PATTERN         = 1;
byte        patternValue            = DEFAULT_PATTERN;

const int   MAX_BRIGHTNESS          = 255;
const int   DEFAULT_BRIGHTNESS      = 20;
int         brightnessValue         = DEFAULT_BRIGHTNESS;

//ESPNOW
// Receivers
// I think 10 is a good maximum, but feel free
// to try more if you like.
// It appears at 10 receivers, each one gets
// an update every 250 mS.
const int NUM_RECEIVERS = 6;
uint8_t memberESPs[NUM_RECEIVERS][6] = {//Unit A is the transmitter
                {0x94, 0xB9, 0x7E, 0xC2, 0xD1, 0x00},//Unit B
                {0x7C, 0x9E, 0xBD, 0x49, 0x09, 0x48},//Unit C
                {0x7C, 0x9E, 0xBD, 0x47, 0x3E, 0x08},//Unit D
                {0x7C, 0x9E, 0xBD, 0x48, 0x11, 0x48},//Unit E
                {0x94, 0xB9, 0x7E, 0xE4, 0x58, 0x70},//Unit F
                {0x94, 0xB9, 0x7E, 0xE6, 0x0C, 0x20} //Unit G
                };
esp_now_peer_info_t peerInfo[NUM_RECEIVERS];
esp_err_t result;

// Structure example to send data
// Must match the receiver structure
typedef struct struct_message
    {
    byte  packetVersion=2;
    byte  pattern=1;
    byte  brightness=64;
    byte  monoAverage;
    byte  softpot=0;
    byte  channelData[7];
    } struct_message;

struct_message myData; //structure for data
volatile bool    sendNext = true; //TX pacing
